# Quran_Website

write this command line before run the app:






  pip install django django-jazzmin


Enjoy...
